import React from "react";

const TrendingPosts = () => {
  const posts = [
    { id: 1, title: "Best meme of 2025", likes: 3400 },
    { id: 2, title: "Breaking: Social Media Hack!", likes: 2700 },
    { id: 3, title: "Top 10 productivity tips", likes: 1900 },
  ];

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-bold mb-4">Trending Posts</h2>
      <ul className="space-y-4">
        {posts.map(post => (
          <li key={post.id} className="flex justify-between border-b pb-2">
            <span className="font-medium">{post.title}</span>
            <span className="text-blue-600">{post.likes} ❤️</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TrendingPosts;
