import React from "react";

const TopUsers = () => {
  const users = [
    { id: 1, name: "user1", followers: 12000 },
    { id: 2, name: "user2", followers: 9500 },
    { id: 3, name: "user3", followers: 8900 },
  ];

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-bold mb-4">Top Users</h2>
      <table className="w-full table-auto text-left">
        <thead>
          <tr className="border-b">
            <th className="p-2">Username</th>
            <th className="p-2">Followers</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id} className="hover:bg-gray-100">
              <td className="p-2">@{user.name}</td>
              <td className="p-2">{user.followers.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TopUsers;
