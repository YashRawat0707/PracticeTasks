import React from "react";

const Feed = () => {
  const posts = [
    { id: 1, username: "user1", content: "Loving this new platform!" },
    { id: 2, username: "user2", content: "Just hit 10k followers 🥳" },
    { id: 3, username: "user3", content: "Here's my latest post!" },
  ];

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-bold mb-4">Feed</h2>
      <ul className="space-y-4">
        {posts.map(post => (
          <li key={post.id} className="border-b pb-2">
            <p className="text-lg font-semibold">@{post.username}</p>
            <p className="text-gray-700">{post.content}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Feed;
