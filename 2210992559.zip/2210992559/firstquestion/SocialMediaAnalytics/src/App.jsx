import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Feed from "./pages/Feed.jsx";
import TopUsers from "./pages/TopUsers.jsx";
import TrendingPost from "./pages/TrendingPost.jsx";

const App = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100 p-4">
        <nav className="bg-white p-4 rounded shadow mb-4 flex justify-around">
          <Link to="/" className="text-blue-500 font-semibold">Feed</Link>
          <Link to="/top-users" className="text-blue-500 font-semibold">Top Users</Link>
          <Link to="/trending-posts" className="text-blue-500 font-semibold">Trending Posts</Link>
        </nav>

        <Routes>
          <Route path="/" element={<Feed />} />
          <Route path="/top-users" element={<TopUsers />} />
          <Route path="/trending-posts" element={<TrendingPost />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
